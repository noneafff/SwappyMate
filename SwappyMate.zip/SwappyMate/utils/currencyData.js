// File: utils/currencyData.js

// This file maps currency codes to their symbols and flags.
// The API provides the codes, but not this extra information.
export const CURRENCY_DATA = {
  USD: { symbol: '$', name: 'United States Dollar', flag: '🇺🇸' },
  EUR: { symbol: '€', name: 'Euro', flag: '🇪🇺' },
  JPY: { symbol: '¥', name: 'Japanese Yen', flag: '🇯🇵' },
  GBP: { symbol: '£', name: 'British Pound Sterling', flag: '🇬🇧' },
  AUD: { symbol: '$', name: 'Australian Dollar', flag: '🇦🇺' },
  CAD: { symbol: '$', name: 'Canadian Dollar', flag: '🇨🇦' },
  CHF: { symbol: 'Fr', name: 'Swiss Franc', flag: '🇨🇭' },
  CNY: { symbol: '¥', name: 'Chinese Yuan', flag: '🇨🇳' },
  SEK: { symbol: 'kr', name: 'Swedish Krona', flag: '🇸🇪' },
  NZD: { symbol: '$', name: 'New Zealand Dollar', flag: '🇳🇿' },
  MXN: { symbol: '$', name: 'Mexican Peso', flag: '🇲🇽' },
  SGD: { symbol: '$', name: 'Singapore Dollar', flag: '🇸🇬' },
  HKD: { symbol: '$', name: 'Hong Kong Dollar', flag: '🇭🇰' },
  NOK: { symbol: 'kr', name: 'Norwegian Krone', flag: '🇳🇴' },
  KRW: { symbol: '₩', name: 'South Korean Won', flag: '🇰🇷' },
  TRY: { symbol: '₺', name: 'Turkish Lira', flag: '🇹🇷' },
  RUB: { symbol: '₽', name: 'Russian Ruble', flag: '🇷🇺' },
  INR: { symbol: '₹', name: 'Indian Rupee', flag: '🇮🇳' },
  BRL: { symbol: 'R$', name: 'Brazilian Real', flag: '🇧🇷' },
  ZAR: { symbol: 'R', name: 'South African Rand', flag: '🇿🇦' },
  MYR: { symbol: 'RM', name: 'Malaysian Ringgit', flag: '🇲🇾' },
  IDR: { symbol: 'Rp', name: 'Indonesian Rupiah', flag: '🇮🇩' },
  PHP: { symbol: '₱', name: 'Philippine Peso', flag: '🇵🇭' },
  THB: { symbol: '฿', name: 'Thai Baht', flag: '🇹🇭' },
  VND: { symbol: '₫', name: 'Vietnamese Dong', flag: '🇻🇳' },
  PLN: { symbol: 'zł', name: 'Polish Złoty', flag: '🇵🇱' },
  CZK: { symbol: 'Kč', name: 'Czech Koruna', flag: '🇨🇿' },
  HUF: { symbol: 'Ft', name: 'Hungarian Forint', flag: '🇭🇺' },
  ILS: { symbol: '₪', name: 'Israeli New Shekel', flag: '🇮🇱' },
  DKK: { symbol: 'kr', name: 'Danish Krone', flag: '🇩🇰' },
  AED: { symbol: 'د.إ', name: 'UAE Dirham', flag: '🇦🇪' },
  SAR: { symbol: '﷼', name: 'Saudi Riyal', flag: '🇸🇦' },
  // Add more currencies as needed
};