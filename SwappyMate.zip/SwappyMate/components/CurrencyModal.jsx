// File: components/CurrencyModal.jsx

import React, { useState, useMemo } from 'react';
import {
  Modal,
  SafeAreaView,
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { COLORS } from '../constants/colors'; // <-- 1. IMPORT YOUR COLORS

export default function CurrencyModal({ isVisible, currencies, onSelect, onClose }) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCurrencies = useMemo(() => {
    if (!searchQuery) {
      return currencies;
    }
    const lowercasedQuery = searchQuery.toLowerCase();
    return currencies.filter(currency => 
      currency.code.toLowerCase().includes(lowercasedQuery) ||
      (currency.name && currency.name.toLowerCase().includes(lowercasedQuery))
    );
  }, [currencies, searchQuery]);

  const handleSelect = (currency) => {
    onSelect(currency);
    setSearchQuery('');
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.itemContainer} onPress={() => handleSelect(item)}>
      <Text style={styles.itemFlag}>{item.flag || '🏳️'}</Text>
      <View style={styles.itemTextContainer}>
        <Text style={styles.itemCode}>{item.code}</Text>
        <Text style={styles.itemName}>{item.name}</Text>
      </View>
      <Text style={styles.itemSymbol}>{item.symbol}</Text>
    </TouchableOpacity>
  );

  return (
    <Modal visible={isVisible} onRequestClose={onClose} animationType="slide">
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Select Currency</Text>
          <TouchableOpacity onPress={onClose}>
            {/* 2. UPDATE THE ICON COLOR TO BE VISIBLE ON THE NEW HEADER */}
            <Feather name="x" size={28} color={COLORS.textHeader} />
          </TouchableOpacity>
        </View>

        <View style={styles.searchContainer}>
          <Feather name="search" size={20} color={COLORS.textSubtle} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search currency by code or name"
            placeholderTextColor={COLORS.textSubtle}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        <FlatList
          data={filteredCurrencies}
          renderItem={renderItem}
          keyExtractor={item => item.code}
          keyboardShouldPersistTaps="handled"
        />
      </SafeAreaView>
    </Modal>
  );
}

// --- 3. UPDATE THE STYLESHEET ---
const styles = StyleSheet.create({
  modalContainer: { 
    flex: 1, 
    backgroundColor: COLORS.background 
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: COLORS.header, // Changed to use the header color
    // No border needed now
  },
  headerTitle: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: COLORS.textHeader, // Changed to use the header text color (e.g., white)
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 12,
    margin: 20,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  searchIcon: { 
    marginRight: 10 
  },
  searchInput: { 
    flex: 1, 
    height: 50, 
    fontSize: 16, 
    color: COLORS.textDark 
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border, // Use the consistent border color
  },
  itemFlag: { 
    fontSize: 30, 
    marginRight: 15, 
  },
  itemTextContainer: { 
    flex: 1 
  },
  itemCode: { 
    fontSize: 16, 
    fontWeight: 'bold', 
    color: COLORS.textDark 
  },
  itemName: { 
    fontSize: 14, 
    color: COLORS.textSubtle 
  },
  itemSymbol: { 
    fontSize: 18, 
    fontWeight: 'bold', 
    color: COLORS.textSubtle 
  },
});