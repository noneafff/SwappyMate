// File: app/index.jsx

import React, { useEffect } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { Stack, router } from 'expo-router';
import { COLORS } from '../constants/colors'; // <-- 1. IMPORT YOUR COLORS

export default function SplashScreen() {
  
  useEffect(() => {
    const timer = setTimeout(() => {
      router.replace('/welcome');
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      
      <Image
        source={require('../assets/img/currency-exchange.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <Text style={styles.title}>SwappyMate</Text>
      <Text style={styles.subtitle}>Your converter mate</Text>
    </View>
  );
}

// --- 2. UPDATE THE STYLESHEET ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background, // Changed from hard-coded color
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.textDark, // Changed from '#1D2939'
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: COLORS.textSubtle, // Changed from '#667085'
    fontStyle: 'italic',
  },
});