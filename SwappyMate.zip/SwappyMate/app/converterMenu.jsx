// File: app/converterMenu.jsx

import React, { useState, useEffect, useCallback } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity, 
  SafeAreaView,
  Alert,
  ActivityIndicator,
  Keyboard,
  Image // Make sure Image is imported
} from 'react-native';
import { Stack } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { COLORS } from '../constants/colors';
import CurrencyModal from '../components/CurrencyModal';
import { CURRENCY_DATA } from '../utils/currencyData';

// --- 1. Re-create the CustomHeader component for this screen ---
const CustomHeader = () => {
  return (
    <View style={styles.headerContentContainer}>
      <Image
        source={require('../assets/img/currency-exchange.png')}
        style={styles.headerLogo}
      />
      <Text style={styles.headerTitleText}>SwappyMate</Text>
    </View>
  );
};

export default function ConverterMenu() {
  // --- State and Logic (This part is unchanged) ---
  const [fromCurrency, setFromCurrency] = useState({ code: 'GBP', symbol: '£', flag: '🇬🇧', name: 'British Pound Sterling' });
  const [toCurrency, setToCurrency] = useState({ code: 'MYR', symbol: 'RM', flag: '🇲🇾', name: 'Malaysian Ringgit' });
  const [amount, setAmount] = useState('100');
  const [convertedAmount, setConvertedAmount] = useState('');
  const [conversionRates, setConversionRates] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRatesLoading, setIsRatesLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isModalVisible, setModalVisible] = useState(false);
  const [modalType, setModalType] = useState('from');
  const [allCurrencies, setAllCurrencies] = useState([]);
  const API_KEY = process.env.EXPO_PUBLIC_API_KEY;

  const fetchRates = useCallback(async (baseCurrency) => {
    setIsRatesLoading(true);
    setError(null);
    try {
      const response = await fetch(`https://v6.exchangerate-api.com/v6/${API_KEY}/latest/${baseCurrency}`);
      const data = await response.json();
      if (data.result === 'success') {
        setConversionRates(data.conversion_rates);
        if (allCurrencies.length === 0) {
          const currencyList = Object.keys(data.conversion_rates)
            .map(code => ({ code, ...CURRENCY_DATA[code] }))
            .filter(c => c.name)
            .sort((a, b) => a.code.localeCompare(b.code));
          setAllCurrencies(currencyList);
        }
      } else { throw new Error(data['error-type'] || 'Failed to fetch currency data.'); }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsRatesLoading(false);
    }
  }, [API_KEY, allCurrencies.length]);

  useEffect(() => {
    if (fromCurrency.code) { fetchRates(fromCurrency.code); }
  }, [fromCurrency.code]);
  
  const handleConvert = () => {
    Keyboard.dismiss();
    if (!amount || !conversionRates) return;
    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount)) {
      Alert.alert('Invalid Input', 'Please enter a valid number.');
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      const rate = conversionRates[toCurrency.code];
      if (rate) { setConvertedAmount((numericAmount * rate).toFixed(2).toString()); }
      else { Alert.alert('Error', `Conversion rate for ${toCurrency.code} not found.`); }
      setIsLoading(false);
    }, 300);
  };
  
  const handleSwap = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
    setAmount(convertedAmount);
    setConvertedAmount(amount);
  };
  
  const openModal = (type) => {
    setModalType(type);
    setModalVisible(true);
  };

  const handleSelectCurrency = (currency) => {
    if (modalType === 'from') setFromCurrency(currency);
    else setToCurrency(currency);
    setModalVisible(false);
    setConvertedAmount('');
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* --- 2. UPDATE STACK.SCREEN TO BE LIKE recentConvert.jsx --- */}
      <Stack.Screen
        options={{
          headerShown: true,
          headerStyle: { backgroundColor: COLORS.header },
          headerTintColor: COLORS.textHeader, // Styles back arrow
          headerTitleAlign: 'left',
          headerTitleContainerStyle: { left: -10 },
          headerTitle: () => <CustomHeader />,
          headerBackTitle: 'Menu',
          headerRight: () => ( // Add the settings icon here
            <TouchableOpacity>
              <Feather name="settings" size={24} color={COLORS.textHeader} />
            </TouchableOpacity>
          ),
        }}
      />
      
      {/* The old custom header <View> has been deleted from here */}

      <View style={styles.content}>
        <Text style={styles.pageTitle}>Currency Converter</Text>
        <View style={styles.converterCard}>
          {isRatesLoading ? (
            <ActivityIndicator size="large" color={COLORS.primary} />
          ) : error ? (
            <Text style={styles.errorText}>Could not load rates.</Text>
          ) : (
            <>
              {/* FROM Currency Input */}
              <View style={styles.inputRow}>
                <TouchableOpacity style={styles.currencyInfo} onPress={() => openModal('from')}>
                    <Text style={styles.flag}>{fromCurrency.flag}</Text>
                    <Text style={styles.currencyCode}>{fromCurrency.code}</Text>
                    <Feather name="chevron-down" size={20} color={COLORS.textSubtle} style={{marginLeft: 5}}/>
                </TouchableOpacity>
                <TextInput
                    style={styles.input}
                    value={amount}
                    onChangeText={setAmount}
                    placeholder="0"
                    keyboardType="numeric"
                    returnKeyType="done"
                />
              </View>

              {/* Separator and Swap Button */}
              <View style={styles.separatorContainer}>
                <View style={styles.line} />
                <TouchableOpacity onPress={handleSwap} style={styles.swapButton}>
                  <Feather name="repeat" size={20} color={COLORS.primary} />
                </TouchableOpacity>
                <View style={styles.line} />
              </View>

              {/* TO Currency Display */}
              <View style={styles.inputRow}>
                <TouchableOpacity style={styles.currencyInfo} onPress={() => openModal('to')}>
                    <Text style={styles.flag}>{toCurrency.flag}</Text>
                    <Text style={styles.currencyCode}>{toCurrency.code}</Text>
                    <Feather name="chevron-down" size={20} color={COLORS.textSubtle} style={{marginLeft: 5}}/>
                </TouchableOpacity>
                {isLoading ? (
                  <ActivityIndicator color={COLORS.textDark} />
                ) : (
                  <Text style={styles.resultText}>{convertedAmount}</Text>
                )}
              </View>
            </>
          )}
        </View>
      </View>
      
      {!isRatesLoading && !error && (
        <View style={styles.footer}>
            <TouchableOpacity style={styles.primaryButton} onPress={handleConvert}>
                <Text style={styles.primaryButtonText}>Convert</Text>
            </TouchableOpacity>
        </View>
      )}

      <CurrencyModal
        isVisible={isModalVisible}
        currencies={allCurrencies}
        onSelect={handleSelectCurrency}
        onClose={() => setModalVisible(false)}
      />
    </SafeAreaView>
  );
}

// --- 3. ADD HEADER STYLES AND UPDATE THE REST ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  // Added styles for the custom native header
  headerContentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerLogo: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  headerTitleText: {
    color: COLORS.textHeader,
    fontSize: 20,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textDark,
    marginBottom: 20,
    textAlign: 'center',
  },
  converterCard: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 20,
    shadowColor: COLORS.textDark,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 5,
    minHeight: 180,
    justifyContent: 'center',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  currencyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  flag: {
    fontSize: 32,
    marginRight: 12,
  },
  currencyCode: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textDark,
  },
  input: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.accent || COLORS.primary,
    textAlign: 'right',
    flex: 1,
    marginLeft: 10,
  },
  resultText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.textDark,
    textAlign: 'right',
    flex: 1,
    marginLeft: 10,
  },
  separatorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: COLORS.border,
  },
  swapButton: {
    padding: 8,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 30,
    backgroundColor: COLORS.white,
    marginHorizontal: 10,
  },
  footer: {
    padding: 20,
  },
  primaryButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primaryButtonText: {
    color: COLORS.textHeader,
    fontSize: 16,
    fontWeight: '600',
  },
  errorText: {
    textAlign: 'center',
    color: COLORS.error,
    fontSize: 16,
  },
});