// File: app/mainmenu.jsx

import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  Image, // <-- Make sure Image is imported
  TouchableOpacity, 
  SafeAreaView 
} from 'react-native';
import { Stack, router } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { COLORS } from '../constants/colors';

export default function MainMenu() {
  const handleLogout = () => {
    router.replace('/welcome');
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      
      <View style={styles.header}>
        {/* --- 1. NEW VIEW TO GROUP THE LOGO AND TITLE --- */}
        <View style={styles.headerLeftContainer}>
          {/* 2. ADD THE IMAGE COMPONENT HERE */}
          <Image
            source={require('../assets/img/currency-exchange.png')}
            style={styles.headerLogo}
            resizeMode="contain"
          />
          <Text style={styles.headerTitle}>SwappyMate</Text>
        </View>
        
        <TouchableOpacity onPress={handleLogout}>
          <Feather name="log-out" size={24} color={COLORS.textHeader} />
        </TouchableOpacity>
      </View>
      
      <View style={styles.content}>
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeTitle}>Hey, Welcome!</Text>
          <Text style={styles.welcomeSubtitle}>What would you like to do today?</Text>
        </View>

        {/* --- Cards (No Changes) --- */}
        <TouchableOpacity 
          style={styles.card} 
          onPress={() => router.push('/converterMenu')}
        >
          <Image source={require('../assets/img/dollar-sign.png')} style={styles.cardImage} />
          <View style={styles.cardTextContainer}>
            <Text style={styles.cardTitle}>Currency Converter</Text>
            <Text style={styles.cardDescription}>Perform real-time currency conversions.</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.card}
          onPress={() => router.push('/recentConvert')}
        >
          <Image source={require('../assets/img/history.png')} style={styles.cardImage} />
          <View style={styles.cardTextContainer}>
            <Text style={styles.cardTitle}>View Recent Conversions</Text>
            <Text style={styles.cardDescription}>Check your past conversion history.</Text>
          </View>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// --- 3. THE STYLESHEET IS UPDATED WITH NEW STYLES ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: COLORS.header,
  },
  // New style for the left-side container
  headerLeftContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  // New style for the logo in the header
  headerLogo: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.textHeader,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  welcomeSection: {
    marginBottom: 40,
    alignItems: 'center',
  },
  welcomeTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.textDark,
    marginBottom: 8,
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: COLORS.textSubtle,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: COLORS.textDark,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 5,
  },
  cardImage: {
    width: 50,
    height: 50,
    marginRight: 20,
  },
  cardTextContainer: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textDark,
    marginBottom: 4,
  },
  cardDescription: {
    fontSize: 14,
    color: COLORS.textSubtle,
  },
});