// File: app/recentConvert.jsx

import React from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  SafeAreaView,
  FlatList,
  Image
} from 'react-native';
import { Stack } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { COLORS } from '../constants/colors';

// --- MOCK DATA ---
const mockHistoryData = [
  { id: '1', date: '2024-07-22T10:30:00Z', fromAmount: '100.00', fromCode: 'GBP', fromFlag: '🇬🇧', toAmount: '595.31', toCode: 'MYR', toFlag: '🇲🇾' },
  { id: '2', date: '2024-07-21T15:45:00Z', fromAmount: '1,000.00', fromCode: 'USD', fromFlag: '🇺🇸', toAmount: '925.50', toCode: 'EUR', toFlag: '🇪🇺' },
  { id: '3', date: '2024-07-20T08:00:00Z', fromAmount: '5,000.00', fromCode: 'JPY', fromFlag: '🇯🇵', toAmount: '31.45', toCode: 'USD', toFlag: '🇺🇸' },
];

// --- CustomHeader Component ---
const CustomHeader = () => {
  return (
    <View style={styles.headerContentContainer}>
      <Image
        source={require('../assets/img/currency-exchange.png')}
        style={styles.headerLogo}
      />
      <Text style={styles.headerTitleText}>SwappyMate</Text>
    </View>
  );
};

// --- HistoryItem Component ---
const HistoryItem = ({ item }) => {
  const formattedDate = new Date(item.date).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Feather name="calendar" size={16} color={COLORS.textSubtle} />
        <Text style={styles.dateText}>{formattedDate}</Text>
      </View>
      <View style={styles.conversionRow}>
        <Text style={styles.amountText}>{item.fromAmount} {item.fromCode}</Text>
        <Text style={styles.flagText}>{item.fromFlag}</Text>
      </View>
      <Feather name="arrow-down" size={20} color={COLORS.textSubtle} style={styles.arrowIcon} />
      <View style={styles.conversionRow}>
        <Text style={[styles.amountText, styles.resultText]}>{item.toAmount} {item.toCode}</Text>
        <Text style={styles.flagText}>{item.toFlag}</Text>
      </View>
    </View>
  );
};

// --- Main Screen Component ---
export default function RecentConversionsScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen
        options={{
          headerShown: true,
          headerStyle: { backgroundColor: COLORS.header },
          headerTintColor: COLORS.textHeader,
          headerTitle: () => <CustomHeader />,
          headerBackTitle: 'Back',
          headerTitleAlign: 'left',
          headerTitleContainerStyle: {
            left: -10,
          },
        }}
      />
      
      <FlatList
        data={mockHistoryData}
        renderItem={({ item }) => <HistoryItem item={item} />}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listContainer}
        ListHeaderComponent={<Text style={styles.pageTitle}>Conversion History</Text>}
        // --- THIS IS THE FULLY WRITTEN, CORRECT CODE ---
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Feather name="clock" size={48} color={COLORS.textSubtle} />
            <Text style={styles.emptyText}>No recent conversions found.</Text>
            <Text style={styles.emptySubtext}>Your past conversions will appear here.</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

// --- StyleSheet (Complete and Correct) ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  headerContentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerLogo: {
    width: 30,
    height: 30,
    marginRight: 10,
  },
  headerTitleText: {
    color: COLORS.textHeader,
    fontSize: 20,
    fontWeight: 'bold',
  },
  listContainer: {
    padding: 20,
    paddingBottom: 40, // Add padding to the bottom
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textDark,
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 15,
    shadowColor: COLORS.textDark,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 10,
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  dateText: {
    marginLeft: 8,
    fontSize: 14,
    color: COLORS.textSubtle,
  },
  conversionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  amountText: {
    fontSize: 20,
    fontWeight: '500',
    color: COLORS.textDark,
  },
  resultText: {
    fontWeight: 'bold',
    color: COLORS.primary,
  },
  flagText: {
    fontSize: 24,
  },
  arrowIcon: {
    alignSelf: 'center',
    marginVertical: 8,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 100,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textDark,
  },
  emptySubtext: {
    marginTop: 4,
    fontSize: 14,
    color: COLORS.textSubtle,
  },
});