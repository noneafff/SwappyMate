// File: app/login.jsx

import React, { useState } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  TextInput, 
  TouchableOpacity, 
  SafeAreaView,
  Alert,
  Image 
} from 'react-native';
import { Stack, router } from 'expo-router';
import { COLORS } from '../constants/colors'; // <-- 1. IMPORT YOUR COLORS

export default function LoginScreen() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (!username || !password) {
      Alert.alert('Error', 'Please enter both username and password.');
      return;
    }
    console.log('Logging In with:', { username, password });
    router.replace('/mainmenu'); // I've pointed this to converterMenu to match our flow
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* 2. UPDATE THE HEADER COLORS */}
      <Stack.Screen
        options={{
          headerShown: true,
          title: 'Log In',
          headerStyle: { backgroundColor: COLORS.header },    // Changed
          headerTintColor: COLORS.textHeader,               // Changed
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      />
      
      <View style={styles.content}>
        <View style={styles.header}>
          <Image
            source={require('../assets/img/login.png')}
            style={styles.headerImage}
            resizeMode="contain"
          />
          <Text style={styles.title}>Welcome Back!</Text>
          <Text style={styles.subtitle}>Log in to continue to SwappyMate.</Text>
        </View>

        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Username"
            placeholderTextColor={COLORS.textSubtle} // Changed
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor={COLORS.textSubtle} // Changed
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
          
        <TouchableOpacity 
            style={styles.forgotPasswordContainer}
            onPress={() => router.push('/forgotPassword')} // <-- ADD THIS LINE
          >
          <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
        </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.primaryButton} onPress={handleLogin}>
          <Text style={styles.primaryButtonText}>Log In</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// --- 3. UPDATE THE STYLESHEET ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background, // Changed
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  headerImage: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.textDark, // Changed
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: COLORS.textSubtle, // Changed
    textAlign: 'center',
  },
  form: {
    width: '100%',
    marginBottom: 24,
  },
  input: {
    backgroundColor: COLORS.white, // Changed
    borderWidth: 1,
    borderColor: COLORS.border, // Changed
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    marginBottom: 16,
    color: COLORS.textDark, // Changed
  },
  forgotPasswordContainer: {
    alignSelf: 'flex-end',
    marginBottom: 20,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: COLORS.primary, // Changed
    fontWeight: '600',
  },
  primaryButton: {
    backgroundColor: COLORS.primary, // Changed
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    width: '100%',
  },
  primaryButtonText: {
    color: COLORS.textHeader, // Changed (to ensure readability)
    fontSize: 16,
    fontWeight: '600',
  },
});