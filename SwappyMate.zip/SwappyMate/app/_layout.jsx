// File: app/_layout.jsx

import { Stack } from 'expo-router';

export default function RootLayout() {
  return (
    <Stack>
      {/* 
        The first screen is your splash screen (index.js or index.jsx).
        We give it a name 'index' and tell it to hide its header.
      */}
      <Stack.Screen name="index" options={{ headerShown: false }} />

      {/* 
        This is your welcome screen. It uses the header options defined
        within the welcome.jsx file itself.
      */}
      <Stack.Screen name="welcome" />

      {/* 
        This is your main application screen after login/signup.
        It also uses its own header options.
      */}
      <Stack.Screen name="mainmenu" />

      {/* 
        You can add other screens here as well, like login and signup.
        By default, the Stack will show a header with the back button
        when you navigate to them.
      */}
      <Stack.Screen name="signup" />
      <Stack.Screen name="login" />

    </Stack>
  );
}